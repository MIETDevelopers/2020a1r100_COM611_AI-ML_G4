# Salary Prediction System Using ML
 Demo 

<p align= "center"><img src="https://github.com/ROHAN0011/Salary-Prediction-System/blob/149f1d2b01f6f61ab9ae88422589178bb85c0c45/Salary%20Prediction%20System.jpg" width="700" height= "350"></p>
